/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { GameComponent } from "./components/GameComponent";
import { HUD } from "./components/ui/HUD";
import { Inventory } from "./components/ui/Inventory";
import { Dialog } from "./components/ui/Dialog";
import { Quests } from "./components/ui/Quests";

export default function App() {
  const [started, setStarted] = useState(false);

  if (!started) {
    return (
      <div className="w-screen h-screen bg-stone-950 flex flex-col items-center justify-center relative overflow-hidden">
        {/* Background Pattern */}
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: "radial-gradient(#f27d26 1px, transparent 1px)",
            backgroundSize: "40px 40px",
          }}
        />

        {/* Title */}
        <div className="z-10 flex flex-col items-center gap-8">
          <h1 className="text-6xl md:text-8xl font-serif font-bold text-amber-500 tracking-widest uppercase text-center drop-shadow-2xl">
            Fortaleza
            <br />
            do Rosário
          </h1>
          <p className="text-stone-400 text-xl italic font-serif max-w-md text-center">
            Defenda as terras do Duque Mariom Rosário contra as hordas da noite.
          </p>

          {/* Buttons */}
          <div className="flex flex-col gap-4 mt-8 w-64">
            <button
              onClick={() => setStarted(true)}
              className="bg-amber-700 hover:bg-amber-600 text-white font-bold py-4 px-8 rounded-lg transition-all transform hover:scale-105 uppercase tracking-widest shadow-lg border-2 border-amber-900"
            >
              Iniciar Jogo
            </button>
            <button className="bg-stone-800 hover:bg-stone-700 text-stone-300 font-bold py-3 px-8 rounded-lg transition-colors uppercase tracking-widest border-2 border-stone-700 opacity-50 cursor-not-allowed">
              Continuar
            </button>
            <button className="bg-stone-800 hover:bg-stone-700 text-stone-300 font-bold py-3 px-8 rounded-lg transition-colors uppercase tracking-widest border-2 border-stone-700 opacity-50 cursor-not-allowed">
              Configurações
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="absolute bottom-4 text-stone-600 text-sm font-mono">
          MVP v0.1.0 - 476 D.C.
        </div>
      </div>
    );
  }

  return (
    <div className="w-screen h-screen relative overflow-hidden bg-black font-sans">
      <GameComponent />
      <HUD />
      <Quests />
      <Inventory />
      <Dialog />
    </div>
  );
}
