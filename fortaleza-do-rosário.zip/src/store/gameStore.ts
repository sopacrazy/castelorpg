import { create } from "zustand";

export type ResourceType =
  | "gold"
  | "wood"
  | "stone"
  | "essence"
  | "herb"
  | "scrap";

export interface InventoryItem {
  id: string;
  name: string;
  type: "weapon" | "consumable" | "material" | "special";
  description: string;
  quantity: number;
  icon: string;
}

export interface GameState {
  // Player Stats
  health: number;
  maxHealth: number;
  stamina: number;
  maxStamina: number;
  level: number;
  xp: number;
  damage: number;
  defense: number;
  speed: number;

  // Resources
  resources: Record<ResourceType, number>;

  // Inventory
  inventory: InventoryItem[];
  equippedWeapon: InventoryItem | null;

  // Game State
  day: number;
  isNight: boolean;
  enemiesRemaining: number;

  // UI State
  isInventoryOpen: boolean;
  isDialogActive: boolean;
  currentDialog: { name: string; text: string } | null;

  // Castle Upgrades
  castleUpgrades: {
    walls: number;
    gate: number;
    garden: number;
    throneRoom: number;
    warehouse: number;
    watchtower: number;
  };

  // Quests
  quests: {
    id: string;
    description: string;
    completed: boolean;
  }[];

  // Actions
  setHealth: (h: number) => void;
  addResource: (type: ResourceType, amount: number) => void;
  toggleInventory: () => void;
  setDialog: (dialog: { name: string; text: string } | null) => void;
  setDayTime: (isNight: boolean, day: number) => void;
  setEnemiesRemaining: (count: number) => void;
  addItem: (item: InventoryItem) => void;
  upgradeCastle: (part: keyof GameState["castleUpgrades"]) => void;
  completeQuest: (id: string) => void;
}

export const useGameStore = create<GameState>((set) => ({
  health: 100,
  maxHealth: 100,
  stamina: 100,
  maxStamina: 100,
  level: 1,
  xp: 0,
  damage: 10,
  defense: 5,
  speed: 150,

  resources: {
    gold: 0,
    wood: 0,
    stone: 0,
    essence: 0,
    herb: 0,
    scrap: 0,
  },

  inventory: [
    {
      id: "rusty_sword",
      name: "Espada Enferrujada",
      type: "weapon",
      description: "Uma espada velha e gasta, mas ainda corta.",
      quantity: 1,
      icon: "🗡️",
    },
    {
      id: "small_potion",
      name: "Poção Pequena",
      type: "consumable",
      description: "Restaura 25 de vida.",
      quantity: 3,
      icon: "🧪",
    },
  ],
  equippedWeapon: {
    id: "rusty_sword",
    name: "Espada Enferrujada",
    type: "weapon",
    description: "Uma espada velha e gasta, mas ainda corta.",
    quantity: 1,
    icon: "🗡️",
  },

  day: 1,
  isNight: false,
  enemiesRemaining: 0,

  isInventoryOpen: false,
  isDialogActive: false,
  currentDialog: null,

  castleUpgrades: {
    walls: 0,
    gate: 0,
    garden: 0,
    throneRoom: 0,
    warehouse: 0,
    watchtower: 0,
  },

  quests: [
    { id: "q1", description: "Sobreviva à primeira noite", completed: false },
    { id: "q2", description: "Colete 10 madeiras", completed: false },
    { id: "q3", description: "Fale com o Duque", completed: false },
  ],

  setHealth: (h) =>
    set((state) => ({ health: Math.max(0, Math.min(h, state.maxHealth)) })),
  addResource: (type, amount) =>
    set((state) => ({
      resources: { ...state.resources, [type]: state.resources[type] + amount },
    })),
  toggleInventory: () =>
    set((state) => ({ isInventoryOpen: !state.isInventoryOpen })),
  setDialog: (dialog) =>
    set({ currentDialog: dialog, isDialogActive: !!dialog }),
  setDayTime: (isNight, day) => set({ isNight, day }),
  setEnemiesRemaining: (count) => set({ enemiesRemaining: count }),
  addItem: (item) =>
    set((state) => {
      const existing = state.inventory.find((i) => i.id === item.id);
      if (existing) {
        return {
          inventory: state.inventory.map((i) =>
            i.id === item.id
              ? { ...i, quantity: i.quantity + item.quantity }
              : i,
          ),
        };
      }
      return { inventory: [...state.inventory, item] };
    }),
  upgradeCastle: (part) =>
    set((state) => ({
      castleUpgrades: {
        ...state.castleUpgrades,
        [part]: state.castleUpgrades[part] + 1,
      },
    })),
  completeQuest: (id) =>
    set((state) => ({
      quests: state.quests.map((q) =>
        q.id === id ? { ...q, completed: true } : q,
      ),
    })),
}));
