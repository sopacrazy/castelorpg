import Phaser from "phaser";
import { Player } from "../entities/Player";
import { Enemy } from "../entities/Enemy";
import { useGameStore } from "../../store/gameStore";

export class GameScene extends Phaser.Scene {
  private player!: Player;
  private enemies!: Phaser.Physics.Arcade.Group;
  private walls!: Phaser.Physics.Arcade.StaticGroup;
  private crops!: Phaser.Physics.Arcade.StaticGroup;
  private loot!: Phaser.Physics.Arcade.Group;
  private npcs!: Phaser.Physics.Arcade.StaticGroup;
  private dayNightOverlay!: Phaser.GameObjects.Rectangle;

  private waveActive: boolean = false;
  private waveTimer: Phaser.Time.TimerEvent | null = null;
  private enemiesToSpawn: number = 0;
  private spawnInterval: number = 2000;
  private lastSpawnTime: number = 0;

  constructor() {
    super("GameScene");
  }

  create() {
    const width = this.scale.width;
    const height = this.scale.height;

    // Background
    this.add.tileSprite(0, 0, width * 2, height * 2, "grass").setOrigin(0);

    // Physics Groups
    this.walls = this.physics.add.staticGroup();
    this.crops = this.physics.add.staticGroup();
    this.enemies = this.physics.add.group({
      classType: Enemy,
      runChildUpdate: true,
    });
    this.loot = this.physics.add.group();
    this.npcs = this.physics.add.staticGroup();

    // Create Map Elements
    this.createMap();

    // Player
    this.player = new Player(this, width / 2, height / 2);

    // Camera
    this.cameras.main.startFollow(this.player, true, 0.05, 0.05);
    this.cameras.main.setBounds(0, 0, width * 2, height * 2);
    this.physics.world.setBounds(0, 0, width * 2, height * 2);

    // Day/Night Overlay
    this.dayNightOverlay = this.add
      .rectangle(0, 0, width * 2, height * 2, 0x000033, 0)
      .setOrigin(0);
    this.dayNightOverlay.setDepth(100);

    // Collisions
    this.physics.add.collider(this.player, this.walls);
    this.physics.add.collider(this.player, this.crops);
    this.physics.add.collider(this.enemies, this.walls);
    this.physics.add.collider(this.enemies, this.crops);
    this.physics.add.collider(this.enemies, this.enemies);

    // Loot collection
    this.physics.add.overlap(
      this.player,
      this.loot,
      this.collectLoot,
      undefined,
      this,
    );

    // NPC Interaction
    this.physics.add.overlap(
      this.player,
      this.npcs,
      this.interactNPC,
      undefined,
      this,
    );

    // Events
    this.events.on("player-attack", this.handlePlayerAttack, this);
    this.events.on("enemy-died", this.handleEnemyDeath, this);
    this.events.on(
      "enemy-attack-structure",
      this.handleEnemyAttackStructure,
      this,
    );
    this.events.on("player-died", this.handlePlayerDeath, this);

    // Start Day Cycle
    this.startDay();
  }

  update(time: number, delta: number) {
    this.player.update(time, delta);

    if (
      this.waveActive &&
      this.enemiesToSpawn > 0 &&
      time > this.lastSpawnTime + this.spawnInterval
    ) {
      this.spawnEnemy();
      this.lastSpawnTime = time;
    }

    // Check wave end
    if (
      this.waveActive &&
      this.enemiesToSpawn <= 0 &&
      this.enemies.countActive() === 0
    ) {
      this.endNight();
    }
  }

  private createMap() {
    // Simple castle walls
    for (let i = 0; i < 20; i++) {
      this.walls.create(i * 32 + 16, 100, "wall"); // Top wall
      this.walls.create(i * 32 + 16, 500, "wall"); // Bottom wall
    }
    for (let i = 0; i < 12; i++) {
      this.walls.create(16, i * 32 + 100 + 16, "wall"); // Left wall
      this.walls.create(624, i * 32 + 100 + 16, "wall"); // Right wall
    }

    // Crops
    for (let i = 0; i < 5; i++) {
      for (let j = 0; j < 3; j++) {
        this.crops.create(200 + i * 40, 300 + j * 40, "crop");
      }
    }

    // NPCs
    const duke = this.npcs.create(300, 150, "npc");
    duke.setData("name", "Duque Mariom Rosário");
    duke.setData(
      "text",
      "Meu castelo... em ruínas. Você deve proteger as plantações esta noite.",
    );
  }

  private handlePlayerAttack(hitbox: Phaser.Physics.Arcade.Sprite) {
    const state = useGameStore.getState();
    const damage = state.damage;

    this.physics.overlap(hitbox, this.enemies, (box, enemyObj) => {
      const enemy = enemyObj as Enemy;
      const dir = new Phaser.Math.Vector2(
        enemy.x - this.player.x,
        enemy.y - this.player.y,
      ).normalize();
      enemy.takeDamage(damage, dir);
    });
  }

  private handleEnemyDeath(x: number, y: number) {
    const state = useGameStore.getState();
    state.setEnemiesRemaining(Math.max(0, state.enemiesRemaining - 1));

    // Drop loot (50% chance)
    if (Math.random() > 0.5) {
      const drop = this.loot.create(x, y, "loot_gold");
      drop.setData("type", Math.random() > 0.7 ? "essence" : "gold");
      drop.setData("amount", Math.floor(Math.random() * 5) + 1);
    }
  }

  private handleEnemyAttackStructure(structure: any, damage: number) {
    // Simple structure damage logic
    // In a full game, structures would have health
  }

  private collectLoot(player: any, lootObj: any) {
    const loot = lootObj as Phaser.Physics.Arcade.Sprite;
    const type = loot.getData("type");
    const amount = loot.getData("amount");

    useGameStore.getState().addResource(type, amount);
    loot.destroy();
  }

  private interactNPC(player: any, npcObj: any) {
    // Only interact if pressing space/interact key, for now just overlap
    const npc = npcObj as Phaser.Physics.Arcade.Sprite;
    const name = npc.getData("name");
    const text = npc.getData("text");

    // Debounce dialog
    const state = useGameStore.getState();
    if (!state.isDialogActive) {
      state.setDialog({ name, text });

      // Complete quest if talking to Duke
      if (name === "Duque Mariom Rosário") {
        state.completeQuest("q3");
      }
    }
  }

  private handlePlayerDeath() {
    this.scene.pause();
    useGameStore
      .getState()
      .setDialog({
        name: "Fim de Jogo",
        text: "Você caiu em batalha. O castelo está perdido. Recarregue a página para tentar novamente.",
      });
  }

  private startDay() {
    const state = useGameStore.getState();
    state.setDayTime(false, state.day);
    this.waveActive = false;

    // Transition to day
    this.tweens.add({
      targets: this.dayNightOverlay,
      alpha: 0,
      duration: 2000,
      onComplete: () => {
        // Start night after 30 seconds
        this.time.delayedCall(30000, this.startNight, [], this);
      },
    });
  }

  private startNight() {
    const state = useGameStore.getState();
    state.setDayTime(true, state.day);

    // Transition to night
    this.tweens.add({
      targets: this.dayNightOverlay,
      alpha: 0.6,
      duration: 2000,
      onComplete: () => {
        this.waveActive = true;
        this.enemiesToSpawn = 5 + state.day * 2;
        state.setEnemiesRemaining(this.enemiesToSpawn);
      },
    });
  }

  private endNight() {
    const state = useGameStore.getState();
    state.completeQuest("q1");
    state.setDayTime(false, state.day + 1);
    this.startDay();
  }

  private spawnEnemy() {
    this.enemiesToSpawn--;

    // Spawn at random edge
    const edge = Math.floor(Math.random() * 4);
    let x = 0,
      y = 0;
    const w = this.scale.width * 2;
    const h = this.scale.height * 2;

    if (edge === 0) {
      x = Math.random() * w;
      y = -50;
    } // Top
    else if (edge === 1) {
      x = w + 50;
      y = Math.random() * h;
    } // Right
    else if (edge === 2) {
      x = Math.random() * w;
      y = h + 50;
    } // Bottom
    else {
      x = -50;
      y = Math.random() * h;
    } // Left

    // Target a random crop or player
    const target =
      Math.random() > 0.5
        ? this.player
        : this.crops.getChildren()[
            Math.floor(Math.random() * this.crops.getLength())
          ];

    const type = Math.random() > 0.8 ? "medium" : "small";
    const enemy = new Enemy(this, x, y, target as any, type);
    this.enemies.add(enemy);
  }
}
