import Phaser from "phaser";

export class BootScene extends Phaser.Scene {
  constructor() {
    super("BootScene");
  }

  preload() {
    // Generate placeholder textures
    const graphics = this.make.graphics({ x: 0, y: 0 });

    // Player (Blue square)
    graphics.fillStyle(0x0000ff, 1);
    graphics.fillRect(0, 0, 32, 32);
    graphics.generateTexture("player", 32, 32);
    graphics.clear();

    // Enemy (Red square)
    graphics.fillStyle(0xff0000, 1);
    graphics.fillRect(0, 0, 32, 32);
    graphics.generateTexture("enemy", 32, 32);
    graphics.clear();

    // Wall (Gray square)
    graphics.fillStyle(0x888888, 1);
    graphics.fillRect(0, 0, 32, 32);
    graphics.generateTexture("wall", 32, 32);
    graphics.clear();

    // Grass (Green square)
    graphics.fillStyle(0x228b22, 1);
    graphics.fillRect(0, 0, 32, 32);
    graphics.generateTexture("grass", 32, 32);
    graphics.clear();

    // Field/Crop (Yellow square)
    graphics.fillStyle(0xdaa520, 1);
    graphics.fillRect(0, 0, 32, 32);
    graphics.generateTexture("crop", 32, 32);
    graphics.clear();

    // Barricade (Brown square)
    graphics.fillStyle(0x8b4513, 1);
    graphics.fillRect(0, 0, 32, 32);
    graphics.generateTexture("barricade", 32, 32);
    graphics.clear();

    // Sword Hitbox (White transparent)
    graphics.fillStyle(0xffffff, 0.5);
    graphics.fillRect(0, 0, 32, 32);
    graphics.generateTexture("hitbox", 32, 32);
    graphics.clear();

    // Loot (Gold coin)
    graphics.fillStyle(0xffd700, 1);
    graphics.fillCircle(8, 8, 8);
    graphics.generateTexture("loot_gold", 16, 16);
    graphics.clear();

    // NPC (Purple square)
    graphics.fillStyle(0x800080, 1);
    graphics.fillRect(0, 0, 32, 32);
    graphics.generateTexture("npc", 32, 32);
    graphics.clear();
  }

  create() {
    this.scene.start("MainMenuScene");
  }
}
