import { useGameStore } from "../../store/gameStore";

export const Inventory = () => {
  const { isInventoryOpen, toggleInventory, inventory, equippedWeapon } =
    useGameStore();

  if (!isInventoryOpen) return null;

  return (
    <div className="absolute inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-stone-900 border-4 border-stone-700 rounded-xl w-full max-w-2xl max-h-[80vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-stone-800 p-4 border-b-2 border-stone-700 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-amber-500 font-serif tracking-widest uppercase">
            Inventário
          </h2>
          <button
            onClick={toggleInventory}
            className="text-stone-400 hover:text-white transition-colors text-xl font-bold p-2"
          >
            ✕
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 p-6 flex gap-6 overflow-y-auto">
          {/* Left: Equipped & Stats */}
          <div className="w-1/3 flex flex-col gap-4">
            <div className="bg-stone-800 border-2 border-stone-700 rounded-lg p-4">
              <h3 className="text-stone-400 text-sm uppercase font-bold mb-3">
                Equipado
              </h3>
              {equippedWeapon ? (
                <div className="flex items-center gap-3 p-3 bg-stone-900 rounded border border-amber-900/50">
                  <div className="text-3xl">{equippedWeapon.icon}</div>
                  <div>
                    <div className="text-amber-400 font-bold text-sm">
                      {equippedWeapon.name}
                    </div>
                    <div className="text-stone-500 text-xs">
                      {equippedWeapon.type}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-stone-600 text-sm italic">
                  Nenhuma arma equipada
                </div>
              )}
            </div>

            <div className="bg-stone-800 border-2 border-stone-700 rounded-lg p-4 flex-1">
              <h3 className="text-stone-400 text-sm uppercase font-bold mb-3">
                Atributos
              </h3>
              <div className="space-y-2 text-sm font-mono">
                <div className="flex justify-between">
                  <span className="text-stone-500">Dano:</span>
                  <span className="text-red-400">
                    {useGameStore.getState().damage}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">Defesa:</span>
                  <span className="text-blue-400">
                    {useGameStore.getState().defense}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">Velocidade:</span>
                  <span className="text-green-400">
                    {useGameStore.getState().speed}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Grid */}
          <div className="w-2/3 bg-stone-800 border-2 border-stone-700 rounded-lg p-4">
            <h3 className="text-stone-400 text-sm uppercase font-bold mb-3">
              Mochila
            </h3>
            <div className="grid grid-cols-4 gap-3">
              {inventory.map((item) => (
                <div
                  key={item.id}
                  className="bg-stone-900 border-2 border-stone-700 rounded-lg aspect-square flex flex-col items-center justify-center relative hover:border-amber-500 transition-colors cursor-pointer group"
                >
                  <div className="text-4xl mb-1">{item.icon}</div>
                  <div className="absolute bottom-1 right-2 text-xs font-mono text-stone-400 font-bold">
                    x{item.quantity}
                  </div>

                  {/* Tooltip */}
                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 bg-black/90 border border-stone-600 rounded p-2 text-xs opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-10">
                    <div className="text-amber-400 font-bold mb-1">
                      {item.name}
                    </div>
                    <div className="text-stone-300">{item.description}</div>
                  </div>
                </div>
              ))}

              {/* Empty Slots */}
              {Array.from({ length: Math.max(0, 16 - inventory.length) }).map(
                (_, i) => (
                  <div
                    key={`empty-${i}`}
                    className="bg-stone-900/50 border-2 border-stone-800 border-dashed rounded-lg aspect-square"
                  />
                ),
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
