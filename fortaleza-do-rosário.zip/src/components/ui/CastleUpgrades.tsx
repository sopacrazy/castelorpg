import { useGameStore } from "../../store/gameStore";

export const CastleUpgrades = ({
  isOpen,
  onClose,
}: {
  isOpen: boolean;
  onClose: () => void;
}) => {
  const { castleUpgrades, upgradeCastle, resources } = useGameStore();

  if (!isOpen) return null;

  const upgrades = [
    {
      id: "walls",
      name: "Muralhas",
      cost: { stone: 10, wood: 5 },
      desc: "Aumenta a defesa base do castelo.",
    },
    {
      id: "gate",
      name: "Portão Principal",
      cost: { wood: 15, scrap: 5 },
      desc: "Retarda a entrada dos monstros.",
    },
    {
      id: "garden",
      name: "Jardim Real",
      cost: { herb: 10, essence: 2 },
      desc: "Gera ervas curativas diariamente.",
    },
    {
      id: "throneRoom",
      name: "Sala do Trono",
      cost: { gold: 50, stone: 20 },
      desc: "Aumenta o prestígio e atrai mercenários.",
    },
  ];

  return (
    <div className="absolute inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-stone-900 border-4 border-stone-700 rounded-xl w-full max-w-2xl max-h-[80vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-stone-800 p-4 border-b-2 border-stone-700 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-amber-500 font-serif tracking-widest uppercase">
            Restauração do Castelo
          </h2>
          <button
            onClick={onClose}
            className="text-stone-400 hover:text-white transition-colors text-xl font-bold p-2"
          >
            ✕
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 p-6 overflow-y-auto">
          <div className="grid grid-cols-1 gap-4">
            {upgrades.map((upg) => {
              const currentLevel =
                castleUpgrades[upg.id as keyof typeof castleUpgrades] || 0;

              // Check if can afford
              const canAfford = Object.entries(upg.cost).every(
                ([res, amount]) => {
                  return (
                    resources[res as keyof typeof resources] >=
                    amount * (currentLevel + 1)
                  );
                },
              );

              return (
                <div
                  key={upg.id}
                  className="bg-stone-800 border-2 border-stone-700 rounded-lg p-4 flex justify-between items-center"
                >
                  <div>
                    <h3 className="text-amber-400 font-bold text-lg">
                      {upg.name}{" "}
                      <span className="text-stone-500 text-sm">
                        Nível {currentLevel}
                      </span>
                    </h3>
                    <p className="text-stone-400 text-sm mt-1">{upg.desc}</p>

                    {/* Costs */}
                    <div className="flex gap-3 mt-3">
                      {Object.entries(upg.cost).map(([res, amount]) => (
                        <div
                          key={res}
                          className={`text-xs font-mono font-bold ${resources[res as keyof typeof resources] >= amount * (currentLevel + 1) ? "text-green-400" : "text-red-400"}`}
                        >
                          {res === "gold"
                            ? "💰"
                            : res === "wood"
                              ? "🪵"
                              : res === "stone"
                                ? "🪨"
                                : res === "essence"
                                  ? "🔮"
                                  : res === "herb"
                                    ? "🌿"
                                    : "⚙️"}
                          {amount * (currentLevel + 1)}
                        </div>
                      ))}
                    </div>
                  </div>

                  <button
                    disabled={!canAfford}
                    onClick={() => {
                      // Deduct resources
                      Object.entries(upg.cost).forEach(([res, amount]) => {
                        useGameStore
                          .getState()
                          .addResource(
                            res as any,
                            -(amount * (currentLevel + 1)),
                          );
                      });
                      upgradeCastle(upg.id as any);
                    }}
                    className={`px-6 py-3 rounded font-bold uppercase tracking-widest text-sm transition-colors ${
                      canAfford
                        ? "bg-amber-700 hover:bg-amber-600 text-white cursor-pointer"
                        : "bg-stone-700 text-stone-500 cursor-not-allowed"
                    }`}
                  >
                    Melhorar
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
