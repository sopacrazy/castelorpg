import { useGameStore } from "../../store/gameStore";

export const Dialog = () => {
  const { isDialogActive, currentDialog, setDialog } = useGameStore();

  if (!isDialogActive || !currentDialog) return null;

  return (
    <div className="absolute bottom-8 left-1/2 -translate-x-1/2 w-full max-w-3xl z-50 px-4">
      <div className="bg-stone-900 border-4 border-stone-700 rounded-xl shadow-2xl overflow-hidden flex flex-col relative">
        {/* Header */}
        <div className="bg-stone-800 p-3 border-b-2 border-stone-700 flex justify-between items-center">
          <h3 className="text-xl font-bold text-amber-500 font-serif tracking-widest uppercase">
            {currentDialog.name}
          </h3>
          <button
            onClick={() => setDialog(null)}
            className="text-stone-400 hover:text-white transition-colors text-xl font-bold px-2"
          >
            ✕
          </button>
        </div>

        {/* Content */}
        <div className="p-6 text-stone-300 text-lg leading-relaxed font-serif italic">
          "{currentDialog.text}"
        </div>

        {/* Footer */}
        <div className="bg-stone-800 p-3 border-t-2 border-stone-700 flex justify-end">
          <button
            onClick={() => setDialog(null)}
            className="bg-amber-700 hover:bg-amber-600 text-white font-bold py-2 px-6 rounded transition-colors uppercase tracking-widest text-sm"
          >
            Continuar
          </button>
        </div>
      </div>
    </div>
  );
};
