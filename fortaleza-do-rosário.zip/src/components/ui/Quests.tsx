import { useGameStore } from "../../store/gameStore";

export const Quests = () => {
  const { quests } = useGameStore();

  return (
    <div className="absolute top-24 right-4 w-64 bg-stone-900/80 border-2 border-stone-700 rounded-md p-3 pointer-events-none">
      <h3 className="text-amber-500 font-bold text-sm uppercase tracking-widest mb-2 border-b border-stone-700 pb-1">
        Objetivos
      </h3>
      <ul className="space-y-2">
        {quests.map((quest) => (
          <li key={quest.id} className="flex items-start gap-2 text-sm">
            <span
              className={`mt-0.5 ${quest.completed ? "text-green-500" : "text-stone-500"}`}
            >
              {quest.completed ? "✓" : "○"}
            </span>
            <span
              className={`${quest.completed ? "text-stone-500 line-through" : "text-stone-300"}`}
            >
              {quest.description}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
};
