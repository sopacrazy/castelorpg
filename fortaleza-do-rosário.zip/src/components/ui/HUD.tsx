import { useState } from "react";
import { useGameStore } from "../../store/gameStore";
import { CastleUpgrades } from "./CastleUpgrades";

export const HUD = () => {
  const {
    health,
    maxHealth,
    stamina,
    maxStamina,
    level,
    resources,
    day,
    isNight,
    enemiesRemaining,
  } = useGameStore();
  const [isUpgradesOpen, setIsUpgradesOpen] = useState(false);

  return (
    <>
      <div className="absolute top-0 left-0 w-full p-4 pointer-events-none flex justify-between items-start z-40">
        {/* Top Left: Stats */}
        <div className="flex flex-col gap-2">
          <div className="bg-stone-900/80 border-2 border-stone-700 p-2 rounded-md flex items-center gap-4">
            <div className="text-amber-500 font-bold text-xl">Lv {level}</div>
            <div className="flex flex-col gap-1 w-48">
              <div className="w-full bg-stone-800 h-4 rounded-full overflow-hidden border border-stone-600">
                <div
                  className="bg-red-600 h-full transition-all duration-300"
                  style={{ width: `${(health / maxHealth) * 100}%` }}
                />
              </div>
              <div className="w-full bg-stone-800 h-2 rounded-full overflow-hidden border border-stone-600">
                <div
                  className="bg-green-500 h-full transition-all duration-300"
                  style={{ width: `${(stamina / maxStamina) * 100}%` }}
                />
              </div>
            </div>
            <div className="text-white text-sm font-mono">
              {health}/{maxHealth}
            </div>
          </div>

          {/* Resources */}
          <div className="bg-stone-900/80 border-2 border-stone-700 p-2 rounded-md flex gap-4 text-sm font-mono text-stone-300">
            <div className="flex items-center gap-1">
              <span className="text-yellow-400">💰</span> {resources.gold}
            </div>
            <div className="flex items-center gap-1">
              <span className="text-amber-700">🪵</span> {resources.wood}
            </div>
            <div className="flex items-center gap-1">
              <span className="text-gray-400">🪨</span> {resources.stone}
            </div>
            <div className="flex items-center gap-1">
              <span className="text-purple-500">🔮</span> {resources.essence}
            </div>
          </div>
        </div>

        {/* Top Right: Day/Night Cycle */}
        <div className="flex flex-col gap-2 items-end">
          <div className="bg-stone-900/80 border-2 border-stone-700 p-3 rounded-md flex flex-col items-center min-w-[150px]">
            <div className="text-stone-400 text-xs uppercase tracking-widest font-bold mb-1">
              {isNight ? "Noite" : "Dia"} {day}
            </div>
            <div
              className={`text-2xl font-bold ${isNight ? "text-indigo-400" : "text-amber-400"}`}
            >
              {isNight ? "A Horda Ataca" : "Preparação"}
            </div>
            {isNight && (
              <div className="text-red-500 text-sm mt-2 font-mono">
                Restam: {enemiesRemaining}
              </div>
            )}
          </div>

          <button
            onClick={() => setIsUpgradesOpen(true)}
            className="pointer-events-auto bg-amber-700 hover:bg-amber-600 text-white font-bold py-2 px-4 rounded-md transition-colors uppercase tracking-widest text-xs border-2 border-amber-900 shadow-lg w-full text-left"
          >
            🏰 Restaurar Castelo
          </button>
          <button
            onClick={() => useGameStore.getState().toggleInventory()}
            className="pointer-events-auto bg-stone-800 hover:bg-stone-700 text-stone-300 font-bold py-2 px-4 rounded-md transition-colors uppercase tracking-widest text-xs border-2 border-stone-700 shadow-lg w-full text-left"
          >
            🎒 Inventário (I)
          </button>
        </div>
      </div>

      <CastleUpgrades
        isOpen={isUpgradesOpen}
        onClose={() => setIsUpgradesOpen(false)}
      />
    </>
  );
};
